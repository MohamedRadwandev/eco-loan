<template>
     <b-container>
          <p class="h3 font-weight-bold mb-5">Next steps</p>
          <ol class="font-weight-bold h4">
               <li>
                    <p class="mb-0">Before quote acceptance</p>

                    <b-card class="h5 rounded-sm py-4" bg-variant="gray-400" border-variant="gray-400">
                         <b-card-text>
                              <ol>
                                   <li>Current lead time is 7-9 weeks</li>
                                   <li>Pebbles to be left onsite as agreed with client</li>
                                   <li>Pavers to be stacked onsite or cut around as agreed with client at $25+gst per paver quantity is to be agreed
                                        prior to
                                        install</li>
                              </ol>
                         </b-card-text>
                    </b-card>
               </li>
               <li>
                    <p class="mb-0">Accepting your quote</p>

                    <b-card class="h5 rounded-sm py-4" bg-variant="gray-400" border-variant="gray-400">
                         <b-card-text>
                              <ol>
                                   <li>Click the PAY DEPOSIT button to accept your quote</li>
                                   <li>You'll have the option to pay by Bank Deposit or Credit Card</li>
                                   <li>Accounts will clear your payment</li>
                                   <li> Operations will then schedule you into the next block of installs</li>
                                   <li>
                                        You'll be emailed the with the date your work will start
                                        <span>(Please note date may be subject to change, based on other booked jobs and weather conditions)</span>
                                   </li>
                                   <li>The above usually takes 2-5 business days to arrange and plan</li>
                                   <li>If required, a final inspection usually occurs within 14 days of job start</li>
                              </ol>
                         </b-card-text>
                    </b-card>
               </li>
               <li>
                    <p class="mb-0">After quote acceptancece</p>
               
                    <b-card class="h5 rounded-sm py-4" bg-variant="gray-400" border-variant="gray-400">
                         <b-card-text>
                              <ol>
                                   <li>Clear the work area/s of all objects including any rubbish, toys, pot plants, furniture etc.</li>
                                   <li>Please also ensure that the access path between our parking area and the work area is clear of furniture and any other
                                   objects.</li>
                                   <li>Eco Lawn requires full access to the driveway, walkways and power.</li>
                              </ol>
                         </b-card-text>
                    </b-card>
               </li>
          </ol>
          
     </b-container>
</template>

<script>
export default {}
</script>
<style scoped>
.card{
     margin-left: -28px;
     margin-top:32px;
}
ol{
     margin-left: -15px;
}
ol li{
     margin-bottom: 60px;
}
ol li ol li:not(:last-child){
     margin-bottom: 24px;
}
ol li ol li:last-child{
     margin-bottom: 0;
}
ol li ol li{
     font-weight: 700;
}
</style>