<template>
  <div class="py-5 bg-green-400">
    <b-container>
      <b-row>
        <b-col cols="12" md="6">
          <p class="h1 font-weight-bold">Job Reference Number</p>
          <p class="h1 font-weight-bold">6085</p>
        </b-col>

        <b-col cols="12" md="6" class="text-left mt-5 mt-md-0">
          <p class="h3 font-weight-bold mb-4">Customer info</p>
          <div class="mb-4">
            <p class="h5 font-weight-bold">Name</p>
            <p class="h5">Victor Du Toit</p>
          </div>

          <div>
            <p class="h5 font-weight-bold">address</p>
            <p class="h5">9 Dida Park Drive, Kume 0891, New Zealand</p>
          </div>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
export default {
}
</script>