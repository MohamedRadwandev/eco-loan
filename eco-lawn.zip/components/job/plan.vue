<template>
     <b-container>
          <p class="h3 font-weight-bold">Plan</p>
          <div class="text-center">
               <b-img src="~/static/imgs/plan.png" alt="Plan" fluid></b-img>
          </div>
     </b-container>
</template>