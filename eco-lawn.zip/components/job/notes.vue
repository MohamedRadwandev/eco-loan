<template>
  <b-container class="mt-5">
    <p class="h3 font-weight-bold">Installer notes</p>

    <b-row class="mt-4">
      <b-col cols="12" md="6">
        <p class="h4 font-weight-bold mb-3">
          Please check if the customer did the following:
        </p>

        <b-card
          class="h5 rounded-sm py-4"
          bg-variant="gray-400"
          border-variant="gray-400"
        >
          <div class="d-flex flex-column" style="gap: 24px">
            <p class="mb-0 font-weight-bold text-uppercase h5">
              Clear the work area/s of all objects including any rubbish, toys,
              pot plants, furniture etc.
            </p>
            <p class="mb-0 font-weight-bold text-uppercase h5">
              Please also ensure that the access path between our parking area
              and the work area is clear of furniture and any other objects.
            </p>
            <p class="mb-0 font-weight-bold text-uppercase h5">
              Eco Lawn requires full access to the driveway and walkways.
            </p>
          </div>
        </b-card>

        <p class="h5 mt-3">
          If a task has not been completed please call Operations prior to work
          commencing.
        </p>
      </b-col>
     <b-col cols="12" md="6"></b-col>
      <b-col cols="12" md="6" class="mt-5 d-flex flex-column">
        <p class="h4 font-weight-bold mb-3">Vehicle access</p>

        <b-card
          class="h5 rounded-sm py-4 flex-grow-1"
          bg-variant="gray-400"
          border-variant="gray-400"
        >
          <div class="d-flex flex-column" style="gap: 24px">
            <div class="d-flex align-items-center">
              <b-icon icon="x-square" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
                Hiace and Dyna Vans
              </p>
            </div>
            <div class="d-flex align-items-center">
              <b-icon icon="check-circle" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
                Service Truck
              </p>
            </div>
            <div class="d-flex align-items-center">
              <b-icon icon="check-circle" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
                Small Hino Trucks
              </p>
            </div>
            <div class="d-flex align-items-center">
              <b-icon icon="check-circle" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
                Class 2 Hino
              </p>
            </div>
          </div>
        </b-card>
      </b-col>
      <b-col cols="12" md="6" class="mt-5 d-flex flex-column">
        <p class="h4 font-weight-bold mb-3">Tools needed</p>

        <b-card
          class="h5 rounded-sm py-4 flex-grow-1"
          bg-variant="gray-400"
          border-variant="gray-400"
        >
          <div class="d-flex flex-column" style="gap: 24px">
            <div class="d-flex align-items-center">
              <b-icon icon="x-square" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
               A Timber toolkit
              </p>
            </div>
            <div class="d-flex align-items-center">
              <b-icon icon="check-circle" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
               A turf installer toolkit
              </p>
            </div>
            <div class="d-flex align-items-center">
              <b-icon icon="check-circle" font-scale="1.7"></b-icon>
              <p class="mb-0 ml-3 h5 font-weight-bold text-uppercase">
               sand spreader, combi, power sweeper, blower, sand, adhesive, joining tape
              </p>
            </div>
   
          </div>
        </b-card>
      </b-col>
    </b-row>
  </b-container>
</template>

<script>
export default {};
</script>