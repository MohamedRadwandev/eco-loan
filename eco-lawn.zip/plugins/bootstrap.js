import Vue from 'vue'
import { BootstrapVueIcons } from 'bootstrap-vue'

Vue.use(BootstrapVueIcons);