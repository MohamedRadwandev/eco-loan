export default function ({ app, $axios }) {

     // app.router.beforeEach(async (to, from, next) => {
     //      const data = {
     //           grant_type: 'client_credentials',
     //           scope: '*',
     //           client_id: app.$config.client_id,
     //           client_secret: app.$config.client_secret
     //      }


     //      await $axios.post('oauth/token', data).then(data => {

     //           localStorage.setItem('token', data.data.access_token);
     //      })


     //      next();

     // })
}