<template>
     <div>
          <JobBanner />
          <JobNotes />
          <JobProducts />
          <JobPlan />
     </div>
</template>

<script>
export default {};
</script>
